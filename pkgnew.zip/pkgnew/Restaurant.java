package pkgnew;
import java.util.Scanner;
public class Restaurant {
public double ItemPrice;
public String ItemName;
public String Menu;
Scanner sc = new Scanner(System.in);
public double Order = sc.nextDouble(); 
Scanner take= new Scanner(System.in);
int Take = take.nextInt();
 public void Prices(double Price1,double Price2,double Price3){
if (Order == 1) {
this.ItemPrice = Price1;
}
if (Order==2) {
this.ItemPrice = Price2;
}
if (Order == 3) {
this.ItemPrice = Price3;}
System.out.println(ItemPrice);
}
 public void Menu(String Item1,String Item2,String Item3){
if (Order == 1) {
this.ItemName = Item1;
}
if (Order==2) {
this.ItemName = Item2;
}
if (Order == 3) {
this.ItemName = Item3;}
System.out.println(ItemName);
}
 
 public void Reservation(int NumberB){
}
 
 public void Dates(String O, String C){
    
 }
 

 



}
 




   


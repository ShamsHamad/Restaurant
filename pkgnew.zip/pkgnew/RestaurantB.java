package pkgnew;

 class RestaurantB extends Restaurant {

double Prices(){
super.Prices(37, 19, 45.5);  
return Order;
}
double Menu(){
super.Menu("Burger","Potato","Fish");  
return Order;
}


@Override
public  void Reservation(int ChairB){
 ChairB = ChairB-Take;
if(ChairB>0){
    
    System.out.println(ChairB + " Left blank");
 
}else{
    System.out.println("No available chairs");         
}       
    
} 
public void  Check(Boolean CheckB){
}

@Override
public void Dates(String OpenB, String CloseB){
 System.out.println("Open is  "+ OpenB +"\n Close is "+ CloseB );

}

}   
    

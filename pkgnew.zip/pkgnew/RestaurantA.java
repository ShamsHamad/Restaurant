package pkgnew;

public class RestaurantA extends Restaurant {
 
public double Prices(){
super.Prices(72, 26.5, 13);  
return Order;
}
public double Menu(){
super.Menu("Pizza","Pasta","Soda");  
return Order;
}
 
@Override
public  void Reservation(int ChairA){
    ChairA = ChairA-Take;
if(ChairA>0){
    
    System.out.println(ChairA + " Left blank");
 
}else{
    System.out.println("No available chairs");         
}       
    
}   
public void Dates(String OpenA, String CloseA){
 System.out.println("Open is  "+ OpenA +"\n Close is "+ CloseA );

}
}  







    




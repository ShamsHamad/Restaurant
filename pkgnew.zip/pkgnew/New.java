/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkgnew;

/**
 *
 * @author user
 */
public class New {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args){ 
    RestaurantA PriceA = new RestaurantA();
    PriceA.Prices();
    PriceA.Menu();
    PriceA.Reservation(30);
    PriceA.Dates("10 am", "9 am");
    RestaurantB PriceB = new RestaurantB();
    PriceB.Prices();
    PriceB.Menu();
    PriceB.Reservation(25);
    PriceB.Dates("9 am", "12 am");
    }
    
    }    
    
   
   
   
    
    

